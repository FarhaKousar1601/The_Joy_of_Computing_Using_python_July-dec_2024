# In this assignment, your task is just to read the input number and print it.
# Example:

# Input:
# 10

# Output:
# 10
# -------------------------------------------------------------------------------------------------------------

a = int(input())
print(a, end="")