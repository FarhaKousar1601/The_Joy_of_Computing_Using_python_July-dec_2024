#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=283
x=input();
print(x[x.index('@')+1:-4],end="");
