#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=285

print('YES' if(int(input())%6 in [0,1,3]) else 'NO',end='')
