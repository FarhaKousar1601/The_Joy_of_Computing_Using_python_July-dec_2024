#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=289

print(','.join(list(map(lambda d:str(round((2*50*int(d)/30)**0.5)),input().split(',')))),end='')
