#link for the question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=284

print('NO' if input().replace(' ','').isalnum() else 'YES',end='')
