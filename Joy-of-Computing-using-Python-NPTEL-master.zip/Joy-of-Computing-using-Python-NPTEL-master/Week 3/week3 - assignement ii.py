#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=264

[print(i,end=' ') for i in input().split() if int(i)%3!=0]
