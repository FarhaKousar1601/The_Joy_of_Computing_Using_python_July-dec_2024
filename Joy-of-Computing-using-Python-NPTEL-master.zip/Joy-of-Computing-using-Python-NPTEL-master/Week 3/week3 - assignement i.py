#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=262

s=list(map(int,input().split()));
print(max(s),min(s),end="",sep=" ");
