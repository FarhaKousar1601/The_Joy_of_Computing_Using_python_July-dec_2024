#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=288
print(','.join(sorted(input().split(','))),end='');
