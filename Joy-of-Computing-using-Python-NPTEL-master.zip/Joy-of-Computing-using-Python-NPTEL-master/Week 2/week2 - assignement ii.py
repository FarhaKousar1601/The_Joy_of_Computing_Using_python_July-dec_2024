#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=260

a,b=map(int,input().split());
print(a if a>b else b,end="");
