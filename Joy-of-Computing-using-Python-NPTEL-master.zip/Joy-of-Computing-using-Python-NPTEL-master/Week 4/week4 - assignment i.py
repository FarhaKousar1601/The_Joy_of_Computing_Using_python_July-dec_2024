#link for question
#https://onlinecourses.nptel.ac.in/noc19_cs09/progassignment?name=266

fact=1
for i in range(1,int(input())+1):
    fact=fact*i;
print(fact,end="");
