n = int(input())
for num in range(1, n + 1):
  for i in range(num):
    print (num, end = "") #printing number
  print()