# Week 2 Quiz 💡

**1. What will be the output for the following program if the user gives an input value of 3 to it?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W2Q1.PNG" alt="">

- 15
- 33333  ✅
- Error message
- 555

**2. Which of these statements in python will throw anerror when executed?**
- print( “Hello” )
- print( ‘Hello’ )
- print( “ ‘Hello’ “ )
- print( “ “Hello” ” )  ✅

**3. What will be the output of the following code when  executed?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W2Q3.PNG" alt="">

- It will print numbers from 3 to 30
- It will print multiples of 3 till 30
- It will print multiples of 3 till 27  ✅
- It will print 3 thirty times

**4. What will the output of the following code be when executed?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W2Q4.PNG" alt="">

- 7.5\  
  7  ✅
- 7.5\
  7.5
- 7\
  7
- 7.5\
  2
  
**5. What value will c store in it after the execution of the below code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W2Q5.PNG" alt="">

- Value of b multiplied by 3
- Cube of b
- Value of b multiplied with 3 twice
- It will throw an error  ✅

**6. Python was named after the television show Monty Python's Flying Circus.**

- False
- True  ✅

**7. What will the output of the following program be?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W2Q7.PNG" alt="">

- < class 'str' >  ✅ 
- < class 'int' > 
- < class 'number' > 
- < class 'variable ' >

**8. What will the output of the following program be?**

- It will show an error
- Hello! Welcome to Joy of Computing using  Python course  ✅
- 47
- a+b

**9. The python ﬁles will be saved with a .python extension**
 
- False  ✅
- True

**10. What is the output for the following program?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W2Q10.PNG" alt="">

- True
- False  ✅
- It will display an error message
- Boolean
