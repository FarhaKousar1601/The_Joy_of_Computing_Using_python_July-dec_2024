num = int(input())
print(num**2, end="")
