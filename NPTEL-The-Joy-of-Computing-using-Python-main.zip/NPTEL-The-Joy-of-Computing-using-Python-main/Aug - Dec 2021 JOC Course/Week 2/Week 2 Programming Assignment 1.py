name = input()
print("Hello " + name + " ! Welcome to JOCP", end="")
