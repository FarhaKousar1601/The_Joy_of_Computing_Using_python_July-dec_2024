num = int(input())
discount = num * (15/100)
print(num - discount, end="")
