l, b = map(int, input().split())

print(l*b, end="")