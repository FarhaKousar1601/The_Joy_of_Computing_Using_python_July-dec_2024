a, b, c = map(int, input().split())
max_num = max(a, b, c)
min_num = min(a, b, c)
print(max_num - min_num, end="")