# Week 10 Quiz 💡

**1. Classify the following types of compressed image files as lossy or lossless compression type.**

(1) PNG\
(2) JPEG

- (1) Lossless  ✅\
  (2) Lossey
- (1) Lossey\
  (2) Lossless
- (1) Lossless\
  (2) Lossless
- (1) Lossey\
  (2) Lossey

**2. Compression can be used to reduce or change file size and which of these following attributes?**

- File type
- Resolution
- Bit depth
- All of the above  ✅

**3. NumPy is a python library written partially in python and most parts that require fast computation are written in C or C++. State whether the following statement is true or false.**

- True  ✅
- False

**4. What is the output of the following program ?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/JOC-W10Q04.PNG" alt="">

- 5  ✅
- 2
- 2
- Error message

**5. What is the output of the following program?**

<Img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/JOC-W10Q05.PNG" alt="">

- eo ae a oo a  ✅
- oe ae a oo a
- ae ae a oo a
- None of the above

**6. What is the output of the following program?**
  
<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/JOC-W10Q06.PNG" alt="">

- Wloet o fCmuigCus  ✅
- ecm t Jyo CmuigCus
- Welcome to Joy of Computing Course
- None of the above

**7. What will the following function in the program do?**
  
<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/JOC-W10Q07.PNG" alt="">

- Reverse all the strings in the sentence
- Reverse the sentence  ✅
- Reverse the first word of the sentence.
- None of the above

**8. Which of these methods can be used to transpose a matrix X?**
  
- X.Transpose( )
- X.T  ✅
- X.t( )
- X.transpose

**9. What will the following program print?**
  
<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/JOC-W10Q09.PNG" alt="">

- We cannot reshape the array.
- [[ 1 2 3]  ✅\
   [ 4 5 6]\
   [ 7 8 9]
   [10 11 12]]
- [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

**10. What is the output of the following program?**
  
<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/JOC-W10Q10.PNG" alt="">

- 7
- 12
- 10
- 21  ✅
