# Week 0 Quiz 💡

**1. What is the circumference of a circle inscribed inside a rectangle with a length of 8 meters and breadth of 4 meters ?**
- 12.57  ✅
- 25.132
- 6.28
- 50.27

**2. What is the sum of the first 27 odd numbers?**
- 8109
- 729  ✅
- 27
- 108

**3. What is the Least Common Multiple of 12 and 8?**
- 2
- 12
- 8
- 24  ✅

**4. If the length of the square is thrice its original length, its perimeter will be 120 meters. What is the original length of the square?**
- 30
- 10  ✅
- 40
- 20

**5. In a class, there are 80 students who have taken science which is 40% of the total strength. 20% of students have taken maths and the remaining students have taken english. How many students have taken english?**
- 80  ✅
- 400
- 200
- 40

**6. Find the next number of the sequence 1, 5, 13, 25, _______**
- 29
- 41  ✅
- 33
- 37

**7. If the perimeter of the square is 100, what is the area of the square?**
- 10000
- 2500
- 625  ✅
- 1000

**8. If the circumference of the circle is 31.4, what is the area of the circle?**
- 78.5  ✅
- 314
- 15.6
- 15.6

**9. What is the golden value ratio?**
- 1.618  ✅
- 1.168
- 1.861
- None of the above.

**10. Choose the odd one out. 1, 2, 3, 5**
- 1  ✅
- 5
- 3
- None of the above
