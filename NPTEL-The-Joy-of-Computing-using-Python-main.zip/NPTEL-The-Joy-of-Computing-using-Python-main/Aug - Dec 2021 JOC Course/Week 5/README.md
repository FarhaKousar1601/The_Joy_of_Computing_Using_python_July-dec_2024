# Week 5 Quiz 💡

**1. What will the output of the following program be?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W5Q1.png" alt="">

- They are equal
- They are not equal  ✅
- It will throw an error

**2. What will the output of the following program be?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W5Q2.png" alt="">

- name Joy of computing\
  Length 12 Weeks\
  Professor_name Dr Sudarshan Iyengar\
  Language Python  ✅
- {'name': 'Joy of computing', 'Length': Sudarshan Iyengar', 'Language': 'Python'}
- It will throw an error
- dictB will be empty

**3. A file with the .wav or .wave file extension is a Waveform Audio File Format. True or False?**

- False
- True  ✅

**4. In the Monty Hall problem, under the standard assumptions, contestants who switch have a ___ chance of winning the car, while contestants
who stick to their initial choice have only ____ chance.**

- 1/2, 1/2
- 2/3, 1/3  ✅
- 1/3, 2/3
- 1/3, 1/3

**5. In the game ‘Rock, Paper and Scissor’ , if player1 enters 123478 and player2 enters 347653 with the secrets bits as 3 and 5 respectively, then who wins the game? (Assume that player1_list=[“rock”, “paper”, “scissor”] and player2_list=[“paper” ,”scissor”, “rock”])**

- Player1 wins the game
- Player2 wins the game
- It will be a draw  ✅
- Insufficient data

**6. Which is the fastest sorting algorithm?**

- Bubble Sort
- Bucket Sort
- Quick Sort  ✅
- Insertion Sort

**7. Which of these following statements are true with respect to the program below?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W5Q7.png" alt="">

- The value of sum will always be between 1 and 11
- The value of sum will be from 2 to 12  ✅
- The value of sum will be within 12
- The maximum value of sum cannot exceed 6

**8. What is the average time complexity of binary search if the numbers are arranged in descending order and the search is unsuccessful?**

- log2 (n+1)
- log2 (n)  ✅
- log2 (n^2)
- None of the following

**9. What Is the output of the following program?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W5Q9.png" alt="">

- 100
- 0  ✅
- 108
- 109

**10. Will the following program give an error?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/cs75W5Q10.png" alt="">

- Yes
- No  ✅
