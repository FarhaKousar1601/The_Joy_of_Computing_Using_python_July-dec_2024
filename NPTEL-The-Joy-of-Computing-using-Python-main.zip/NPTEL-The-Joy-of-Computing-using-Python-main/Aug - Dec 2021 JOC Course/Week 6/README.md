# Week 6 Quiz 💡

**1. If PYTHON is SVWERK, what is COMPUTING?**

- FLPMXQLKJ  ✅
- FRPSXWLQJ
- Insufficient data
- ZLJMSQFKD

**2. What operation will the following program do?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q2.png" alt="">

- Shift the letter by 6 to the right and then print the capital of that letter.  ✅
- Shift the letter by 6 to the left and then print the capital of that letter.
- Shift the letter by 6 to the right and then print the small letter.
- Shift the letter by 6 to the left and then print the small letter.

**3. What is the output of the following program?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q3.png" alt="">

- False
- True  ✅

**4. What will be the output of the following program?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q4.png.png" alt="">

- ll,adwlolt o fcmuigcus
- hlo n lcm ojyo optn orl  ✅
- hello, and welcome to jy of computing course
- It will show an error

**5. The array object in NumPy is called ndarray and NumPy is faster than Lists. State whether the above statement is true or false.**

- True  ✅
- False

**6. What is the output of the following program? ( Assuming that k and n are any 2 positive numbers)**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q6.png" alt="">

- It will find the value of k raised to the power of k
- It will find the value of n raised to the power of k
- It will find the value of k raised to the power of n  ✅
- It will find the value of n raised to the power of n

**7. The output of the following program is as follows\
[[ 1 4 13]\
[ 2 2 9]\
[ 3 3 6]]\
What should be written in the empty blank in the following program to get the
above desired output?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q7.png" alt="">

- numpy.transpose(arr)  ✅
- arr.transpose( )
- Either a or b options can be used
- arr.reverse( )

**8. Which of the following programs will calculate the factorial of a given number?**

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q8a.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q8b.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs75/A6Q8c.png" alt="">  ✅

- None of the following

**9. In tic tac toe game, if player 1 starts the game by marking ‘X’ in the center of the matrix, then he has more chances of winning. State whether the above given statement is true or false.**

- True  ✅
- False

**10. Recursive programs are faster than the iterative programs. State whether the following statement is true or false.**

- True
- False  ✅
