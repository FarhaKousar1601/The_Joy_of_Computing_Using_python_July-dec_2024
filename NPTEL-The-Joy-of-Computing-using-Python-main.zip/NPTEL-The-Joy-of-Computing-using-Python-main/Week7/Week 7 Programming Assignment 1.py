k = input().split(" ")

j = input().split(" ")

if j[0] == k[0]:
  
  print("Yes")
  
else:
  
  print("No")