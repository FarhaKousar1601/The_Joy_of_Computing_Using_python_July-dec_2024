# Week 6 Quiz 💡


**1. In Caesar cipher,the mediator needs to make maximum of how many trails to break the code?**
- 1
- 26  ✅
- no trail needed
- 10



**2. What is the result of the following code if the input is COMPUTING?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q2.png" alt="">

- FRPSXWLQJ
- HTRUZYNSL
- GSQTYXMRK  ✅
- none of the above


**3. Which of the following is TRUE about MIN-MAX strategy?**
- Maximise the chances of your winning and minimize the changes of the opponent winning  ✅
- The game with min-max strategy can never be drawn
- minimise the chances of your winning and maximize the chances of the opponent winning
- All the above are true

**4. What is the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q4.png" alt="">

- Greatest common factor of num1 and num2  ✅
- Least common factor of num1 and num2
- Least common multiple of num1 and num2
- Greatest common multiple of num1 and num2

**5. What does the following python code compute?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q5.png" alt="">

- power of a raised to b
- sum of a and b
- product of a and b  ✅
- none of the above

**6. Which of the following is not true about recursion?**
- The speed of a program using recursion is same as that of the speed of its non-recursive equivalent
- The speed of a program using recursion is slower than the speed of its non-recursive equivalent
- The speed of a program using recursion is faster than the speed of its non-recursive equivalent  ✅
- Recursive programs are easier to understand and code than that of its non-recursive equivalent

**7. Which of the following is the optimal code among the given codes using recursive binary search?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q7.a.png" alt="">

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q7.b.png" alt="">  ✅

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q7.c.png" alt="">

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q7.d.png" alt="">

**8. What is the result of the following recursive function call?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q8.png" alt="">

- 2  ✅

  6
  
  24

- 1

  2
  
  6
  
  24

- 2

  4
  
  12

- 1

  2
  
  4
  
  12
  
**9. What is the output of the following python code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W6Q9.png" alt="">

- 24
- Runs infinitely
- Recursion error  ✅
- 1

**10. A program can be written using recursive function only if it can be recursively defined.**
- TRUE  
- FALSE  ✅
