# Week 3 Quiz 💡

**1. What is the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q1.png" alt="">  

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q1.a.png" alt="">  ✅

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q1.b.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q1.c.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q1.d.png" alt="">

**2. Consider the list L= [0, 1, 1, 2, 3, 5, 8, 13, 21, 34].What will be output of the statement L [3:6]?**
 - [2, 3, 5]  ✅
 - [0, 1, 1]
 - [1, 2, 3]
 - none

**3. Which of the following is the method to insert an item into a specified position in a list?**
 - Append
 - Insert  ✅
 - Add
 - InsertAt

**4. ___________ method returns the number of occurrences of an element in a list.**
 - NumberOf
 - Total
 - Count  ✅
 - Length

**5. In the game FizzBuzz, what should be the output for the number 510?**
 - Fizz
 - Buzz
 - FizzBuzz  ✅
 - Either A or B

**6. Which of the following trims the list L by 10%**
 - Stats.trim_mean(L, 10)
 - Stats.trim_mean(L, 0.1)  ✅
 - Stats.trim_mean(L, -10)
 - Stats.trim_mean(L, -0.1)

**7. Which of the following code is invalid?**

 - import matplotlib.pyplot as plt\
 plt.plot([1,2,3,4],[1,3,6,9],'b+')

 - import matplotlib.pyplot as plt\
 plt.plot([1,2,3,4],[1,3,6,9],'b++')  ✅

- import matplotlib.pyplot as plt\
plt.plot([1,2,3,4],[1,3,6,9],'b*')

- import matplotlib.pyplot as plt\
  plt.plot([1,2,3,4],[1,3,6,9],'b--')

**8. In how many different ways can you arrange the letters in the word COMP?**
 - 24  ✅
 - 4
 - 6
 - 20

**9. The method open(“file1.txt”, r+) opens the file file1.txt in**
 - Read mode
 - Write mode
 - Read write mode  ✅
 - Append mode

**10. The function random.randint(1,100) in python generates**
 - A random integer between 1 to 100 with 1 and 100 both inclusive  ✅
 - A random integer between 1 to 100 with 1 and 100 both exclusive
 - A random integer between 1 to 100 with only 100 inclusive
 - None of the above
