number = int(input())
print(number)