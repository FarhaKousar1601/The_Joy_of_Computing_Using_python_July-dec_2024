# Week 2 Quiz 💡

**1. When we save a Python code it will be saved as file name with the extension?**
 - .p
 - .pyt
 - .python
 - .py ✅

**2. You are calculating the simple interest using a python program. How do you get the interest as an input from the user?**
 - r=float(input(”Enter the interest rate”)) ✅
 - r=int(input(”Enter the interest rate”))
 - r=input(”Enter the interest rate”)
 - None of these

**3. Consider that you are developing a 2 player game in python. You have taken the names of both the users and stored them as variables user1 and user2.
If you want to say Hi to both the users, print their names and welcome them to your game, which of the following statement(s) will fit to your requirement?**
 - print(”Hi”+user1+”and”+user2+”Welcome to the game”) ✅
 - print(”Hi”,user1,”and”,user2,”Welcome to the game”) ✅
 - print(”Hi”,”user1”,”and”,”user2”,”Welcome to the game”)
 - print(”Hi”+user1,”and”,user2+”Welcome to the game”) ✅

**4. What is the output of this code snippet ?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q4.png" alt="">

 - numbers are equal ✅
 - numbers are not equal

**5. What does the following code snippet print?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q5.png" alt="">	

 - All numbers from 0 to 19
 - Pair of numbers from 0 to 19 whose difference is 2
 - All even numbers from 0 to 19 ✅
 - All odd numbers from 0 to 19

**6. What is the output of the code snippet given?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q6.png" alt="">

 - 10 100
 - 10 90
 - An error will be generated
 - 10 10 ✅
 
**7. Given this code snippet,determine its output?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q7.png" alt="">		

 - 5040 ✅
 - 4050
 - 504
 - 405

**8. Consider the code snippet given, describe its output?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q8.png" alt="">	

 - Some 7 numbers
 - First 6 natural numbers
 - Next 6 Numbers after the input number a ✅
 - Next 7 Numbers after the input number a

**9. Consider the code snippet given, What might be the output of this?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W2Q9.png" alt="">		

 - Decreasing order of natural numbers from 7 ✅
 - Decreasing order of natural numbers from 8
 - Increasing order of natural numbers till 7
 - Increasing order of natural numbers till 8

**10. Which of the following is not a valid variable name?**

 - var-1  ✅
 - var1
 - Var1
 - var 1 ✅
