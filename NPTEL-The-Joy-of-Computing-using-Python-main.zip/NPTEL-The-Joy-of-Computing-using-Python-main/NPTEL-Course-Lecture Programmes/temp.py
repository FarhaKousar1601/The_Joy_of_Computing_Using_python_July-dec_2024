# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
"Hello World"
print("hi")
