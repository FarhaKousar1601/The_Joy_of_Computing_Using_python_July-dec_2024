# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 14:12:27 2021

@author: Lakhan Kumawat
"""
#Lets make a Dictionary named Conv_factor and it is denoted by {}
conv_factor={}
#lets set conv_factor of dollar to 60
conv_factor["Dollar"]=60
print(conv_factor)
conv_factor["Euro"]=50
print(conv_factor)
print(conv_factor['Euro'])
print(conv_factor.keys())
print(conv_factor.values())
print(conv_factor.items())