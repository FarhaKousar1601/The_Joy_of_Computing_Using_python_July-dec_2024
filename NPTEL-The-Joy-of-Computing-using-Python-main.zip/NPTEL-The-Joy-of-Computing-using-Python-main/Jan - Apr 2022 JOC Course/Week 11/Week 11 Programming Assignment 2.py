L=sorted(input().split("#"),reverse=True)
print("#".join(L),end="")
