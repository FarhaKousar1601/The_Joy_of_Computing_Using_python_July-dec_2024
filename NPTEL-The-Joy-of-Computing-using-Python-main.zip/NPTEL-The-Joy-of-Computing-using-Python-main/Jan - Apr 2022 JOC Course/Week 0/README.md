# 📌 Week 0 Quiz

**1. The area of a circle A is the sum of areas of two small circles of diameter 10cm and 24 cm, the diameter of the circle A is?**
- 14
- 26  ✅
- 17
- 34

**2. If a couple of dice are thrown together what will be the probability of getting the same number on both dice?**
- 1/6  ✅
- 1/36
- 1/12
- 1/3

**3. The sum of the first 10 odd natural numbers is ____.**
- 200
- 210
- 100  ✅
- 400

**4. What is the smallest number divisible by both 18 and 57?**
- 400
- 350
- 260
- 342  ✅

**5. Total number of factors any prime number has?**
- 3
- 2  ✅
- 0
- 1

**6. The HFC of 12 and 18 is?**
- 2
- 3
- 4
- 6  ✅

**7.  If two dice are thrown together what is the probability of getting an even number on both dice?**
- 1/6
- 1/36
- 1/4  ✅
- 1/2

**8. If a number between 1 and 30 is chosen at random what is the probability of getting a prime number?**
- 2/3
- 1/3  ✅
- 1/6
- 11/13

**9. If the radius has doubled the area of the circle will?**
- 2 times
- 4 times  ✅
- 8 times
- 16 times

**10. If the perimeter of a circle is equal to that of a square, then the ratio of their areas is**
- 22: 7
- 14: 11  ✅
- 7: 22
- 11: 14
