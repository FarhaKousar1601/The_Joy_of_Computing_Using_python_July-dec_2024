def subStr(s1,s2):
  return(s2 in s1)
