roll=input()
print(roll.split('@')[0],roll.split('@')[1].split(".")[0],end="")