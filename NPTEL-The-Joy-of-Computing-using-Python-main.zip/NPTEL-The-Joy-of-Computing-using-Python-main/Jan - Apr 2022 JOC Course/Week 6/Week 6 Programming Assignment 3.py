def whole(N):
  return(sum(list(range(N+1))))
