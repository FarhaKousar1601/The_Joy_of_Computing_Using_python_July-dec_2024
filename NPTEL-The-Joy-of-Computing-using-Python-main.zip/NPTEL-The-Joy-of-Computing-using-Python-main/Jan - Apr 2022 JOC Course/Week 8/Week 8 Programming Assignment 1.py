def squareT(t):
  L=[]
  for i in t:
    L.append(i*i)
  return(tuple(list(t)+L))
    