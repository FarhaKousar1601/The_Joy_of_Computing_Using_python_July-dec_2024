# Week 7 Quiz

**1. Values of CSV files are separated by?**
- Commas  ✅
- Colons
- Semi-colons
- Slash

**2. What is the output of the following code?**
	
<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q2.PNG" alt="">  
	
- 1, 2, 3, 7, 11, 10, 9, 5, 6
- 1, 2, 3, 5, 6, 7, 9, 10, 11
- 1, 5, 9, 10, 11, 7, 3, 2, 6  ✅
- 1, 5, 9, 2, 6, 10, 3, 7, 11

**3. What will be the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q3.PNG" alt="">
	
- Scalar triangle
- Right angle triangle
- Equilateral triangle  ✅
- Isosceles triangle

**4. Which of the following program will draw a hexagon?**

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q4.A.PNG" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q4.B.PNG" alt="">  ✅

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q4.C.PNG" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q4.D.PNG" alt="">

**5. Which of the following library is used to render data on google maps?**
- gplot
- googlemaps
- gmplot  ✅
- gmeplot

**6. What is the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q6.PNG" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q6.A.PNG" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q6.B.PNG" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q6.C.PNG" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC_W7_Q6.D.PNG" alt="">  ✅
	
**7. Which turtle command is equivalent to lifting up a pen.**

- penlift()
- penup()  ✅
- uppen()
- penremove()

**8. Why do we use functions?**

- To improve readability.
- To reuse code blocks.
- For the ease of code debugging.
- All of the above  ✅

**9. Library used to import images?**

- PIL  ✅
- Imageview
- IMG
- image

**10. In snakes and ladder what can be the ways to track ladders and snakes?**
- Maintain a dictionary with snakes or ladder number blocks as keys.
- Using the if condition to check on every number.
- Both A and B.  ✅
- None of the above
