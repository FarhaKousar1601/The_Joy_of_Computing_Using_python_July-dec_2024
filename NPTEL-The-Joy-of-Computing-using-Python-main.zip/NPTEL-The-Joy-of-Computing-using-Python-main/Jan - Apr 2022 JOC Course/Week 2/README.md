# 📌Week 2 Quiz

**1. Which statement will print ‘The joy of computing’?**
- print(The joy of computing)
- print The joy of computing
- printf(‘The joy of computing’)
- print(‘The joy of computing’)  ✅

**2. What is the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q2.PNG" alt="">
	
 - Earth is round.\
   Moon has lot of dust.
 - Earth is\
   round.\
   Moon has\
   lot of dust. 
- Earth is\
  round.\
  Moon has lot of dust.  ✅  
- Earth is round.Moon has lot of dust.

**3. What should be the syntax of getting age as an input from a user in python?**
- Age = int(“Enter Age”)
- Age = input(“Enter Age”)  ✅
- Age = get(“Enter Age”)
- Age = input(Enter Age)

**4. What should be the value of _ to print all numbers from 0-10?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q4.PNG" alt="">
	
- 10
- 9
- 11  ✅
- None of the above

**5. What will be the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q5.PNG" alt="">
	
- 0
- 45  ✅
- 43
- 50

**6. What will be the output? suppose the input is 20**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q6.PNG" alt="">
	
- 40
- Error
- 2020  ✅
- None of the above

**7. What will be the output of the following code be?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q7.PNG" alt="">

- number is less than 0
- number is greater than 0
- number is zero  
- Error  ✅

**8. What will be the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q8.PNG" alt="">	
  
- 9  ✅
- 10
- 0
- None of the above

**9. What will be the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q9.PNG" alt="">
	
- 56  ✅
- 45
- 0
- Error

**10. What will be the output of the following code?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc22_cs31/JOC-W2-Q10.PNG" alt="">

- 1,2,3,4,5,6,7,8,9,10
- 2,4,6,8,10  ✅
- 0,1,2,3,4,5,6,7,8,9,10
- Error
