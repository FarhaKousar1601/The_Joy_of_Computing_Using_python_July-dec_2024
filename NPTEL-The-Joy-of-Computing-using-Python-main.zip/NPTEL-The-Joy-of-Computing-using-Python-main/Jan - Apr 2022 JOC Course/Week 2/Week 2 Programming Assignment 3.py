num = int(input())
for i in range(0, num+1):
  print(i)