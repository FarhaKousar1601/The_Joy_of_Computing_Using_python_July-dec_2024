num = int(input())
print(num)