# Week 11 Quiz 💡

**1. The python library selenium is used for which of the following concepts**
- File Handling
- Image processing
- Natural Language Processing
- Browser automation  ✅

**2. Which of the following is true about Browser automation?**
- load and performance testing on the websites
- web data extraction
- automated testing
- All of the above  ✅

**3. The python function for converting a number into a string is**
- numtostring()
- str()  ✅
- to_string()
- numstring()

**4. Which of the following is the python library for setting the timezone?**
- pytimezone
- pythonTimeZone
- timezone
- pytz  ✅

**5. Which of the following code snippet will print today’s date?**

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q5.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q5.b.png" alt="">

- Both A and B  ✅
- none

**6. Predict the output:**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q6.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q6.a.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q6.b.png" alt="">  ✅

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q6.c.png" alt="">

- Error

**7. What does the following code print?**

<img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q7.png" alt="">

- Number of leapdays between the specified years  ✅
- Lists all leapdays between the specified years
- Lists the leapdays and its count between the specified years
- None

**8. What does the python function: calendar.weekday(year, month, day) return if the weekday is Friday?**
- 3
- 4  ✅
- 5
- 6

**9. What is the return value of the following python function : datetime.datetime.utcnow()**
- returns the coordinated universal time  ✅
- returns the current user time
- returns the coordinated user time
- returns the concurrent universal time

**10. Which of the following is the correct code to find whether a given year is a leap year or not?**

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q10.a.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q10.b.png" alt="">

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q10.c.png" alt="">  ✅

- <img src="https://storage.googleapis.com/swayam-node1-production.appspot.com/assets/img/noc21_cs32/cs32W11Q10.d.png" alt="">
